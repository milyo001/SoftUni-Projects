﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            {
                var inputJson = File.ReadAllText("./../../../Datasets/cars.json");
                
                using (var db = new CarDealerContext())
                {
                    var result = ImportCars(db, inputJson);
                    Console.WriteLine(result);
                }
            }
        }
        //Problem 9.
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var jsonOutput = JsonConvert.DeserializeObject<Supplier[]>(inputJson);
            context.Suppliers.AddRange(jsonOutput);
            var count = context.SaveChanges();
            return $"Successfully imported {count}.";
        }
        //Problem 10.
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var jsonOutput = JsonConvert.DeserializeObject<Part[]>(inputJson)
                .Where(p => p.SupplierId <= 31);

            context.Parts.AddRange(jsonOutput);
            context.SaveChanges();
            return $"Successfully imported {jsonOutput.Count()}.";
        }
        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var jsonOutput = JsonConvert.DeserializeObject<Car[]>(inputJson);

            context.Cars.AddRange(jsonOutput);
            var count = context.SaveChanges();
            return $"Successfully imported {count}.";
        }
    }
    
}