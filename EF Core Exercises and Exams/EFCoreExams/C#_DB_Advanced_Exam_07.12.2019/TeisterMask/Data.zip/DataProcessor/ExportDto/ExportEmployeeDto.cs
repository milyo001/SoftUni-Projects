﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TeisterMask.Data.Models;

namespace TeisterMask.DataProcessor.ExportDto
{
    public class ExportEmployeeDto
    {
        [JsonProperty("Username")]
        public string Username { get; set; }

        [JsonProperty("Tasks")]
        public ICollection<ExportEmployeeTaskDto> Tasks { get; set; }
    }
}
