﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-NH8M3MM\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
