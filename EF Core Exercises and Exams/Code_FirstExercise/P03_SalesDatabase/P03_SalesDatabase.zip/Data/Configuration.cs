﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-NH8M3MM\SQLEXPRESS;Database=SalesDatabase;Integrated Security=true;";
    }
}
